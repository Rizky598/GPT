#!/bin/bash

# Rizky-AI Bot Dashboard Startup Script
echo "==================================="
echo "  Rizky-AI Bot Dashboard Startup   "
echo "==================================="

# Set working directory
cd "$(dirname "$0")"

# Function to check if port is in use
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null ; then
        return 0
    else
        return 1
    fi
}

# Function to start web dashboard
start_dashboard() {
    echo "Starting web dashboard on port 8080..."
    if check_port 8080; then
        echo "Port 8080 is already in use. Stopping existing process..."
        pkill -f "php -S.*8080"
        sleep 2
    fi
    
    nohup php -S 0.0.0.0:8080 > server.log 2>&1 &
    DASHBOARD_PID=$!
    echo "Dashboard started with PID: $DASHBOARD_PID"
}

# Function to start bot (optional)
start_bot() {
    echo "Do you want to start the Telegram bot? (y/n)"
    read -r start_bot_choice
    
    if [[ $start_bot_choice =~ ^[Yy]$ ]]; then
        echo "Starting Telegram bot..."
        nohup node main.js > bot.log 2>&1 &
    fi
}

# Function to show status
show_status() {
    echo ""
    echo "==================================="
    echo "           System Status           "
    echo "==================================="
    
    # Check dashboard status
    if check_port 8080; then
        echo "✅ Dashboard: Running on http://localhost:8080"
        echo "   Password: Rizky-Ai"
    else
        echo "❌ Dashboard: Not running"
    fi
    
    # Check bot status
    if pgrep -f "node.*main.js" > /dev/null; then
        echo "✅ Telegram Bot: Running"
    else
        echo "❌ Telegram Bot: Not running"
    fi
    
    echo ""
    echo "==================================="
    echo "         Available Features        "
    echo "==================================="
    echo "• Premium Users Management"
    echo "• API Configuration (Bot Token, Google AI)"
    echo "• Bot Monitoring & System Resources"
    echo "• Bot Control (Start/Stop/Restart)"
    echo "• Maintenance Mode Toggle"
    echo ""
    echo "==================================="
    echo "           Instructions            "
    echo "==================================="
    echo "1. Open http://localhost:8080 in your browser"
    echo "2. Login with password: Rizky-Ai"
    echo "3. Configure your bot settings in API Management"
    echo "4. Manage premium users as needed"
    echo "5. Monitor bot status and system resources"
    echo ""
    echo "To stop all services, run: ./stop.sh"
    echo "==================================="
}

# Main execution
echo "Starting Rizky-AI Bot Dashboard System..."
echo ""

start_dashboard
sleep 2
start_bot
sleep 2
show_status

echo ""
echo "System startup completed!"
echo "Press Ctrl+C to view this status again, or run './stop.sh' to stop all services."

