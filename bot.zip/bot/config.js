module.exports = {
    BOT_TOKEN: "7943940179:AAHcd6jZ5Wt-jg9bxKU-YgQQbjlXRK6cqgU", // Ganti dengan token bot Telegram Anda dari @BotFather
    allowedDevelopers: ["7693829809"], // Ganti dengan ID Telegram Anda
    botName: "⚙️ 𝐑𝐢𝐳𝐤𝐲-𝐀𝐢 ⚙️",
    customerServiceAdmin: "Rizky-Ai", // Username Telegram tanpa @ untuk kontak
   
    // 🔍 API KEYS
    GOOGLE_AI_API_KEY: "AIzaSyD1oWILbF2PF7rA1u5Wv1Q2Ezmeul3Vzr0", // Google AI (Gemini, Translate, dll) - Dapatkan dari https://aistudio.google.com/app/apikey
    HF_API_KEY: "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", // HuggingFace - Dapatkan dari https://huggingface.co/settings/tokens
    RUNWAY_API_KEY: "key_99d1df72c1aed105d703c14c8709c615bfadac02bd477e0ecadd6b9a09c0d9438adec5f85f3ee47ba4fe8f617974efd67013ca4847d0b7d0a5798ba150ec0d1c", // RunwayML - Dapatkan dari https://app.runwayml.com/account/api-keys (Fitur ini mungkin memerlukan langganan berbayar)
    IMGBB_API_KEY: "d24c1d6589ed0a7fe102dd15c53b91dd", // ImgBB - Dapatkan dari https://api.imgbb.com/
    WEATHER_API_KEY: "aff5bbcef23393960d441a5e87fadbae", // OpenWeatherMap - Dapatkan dari https://openweathermap.org/api
    SCREENSHOTMACHINE_API_KEY: "420490", // ScreenshotMachine Key - Dapatkan dari https://screenshotmachine.com/a/api.php
    SCREENSHOTMACHINE_SECRET: "420490", // ScreenshotMachine Secret phrase - Dapatkan dari https://screenshotmachine.com/a/api.php
    PEXELS_API_KEY: "3ripsP3Va9qNw9r0ilMWj9mLd6tvbnchByYc7Jr1PCZwwDqzBlwjRzfY",
    DEEPAI_API_KEY: "117e2789-0ff7-446e-aa0d-c89ab35c0dda",
    REMOVEBG_API_KEY: "zoq94wUDQrYyDQv6zUWjRF5S"
};

