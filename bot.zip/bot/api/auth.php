<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . 
'/../config/auth.php';

$auth = new Auth();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (isset($input['action'])) {
            if ($input['action'] === 'login') {
                if (isset($input['password'])) {
                    if ($auth->login($input['password'])) {
                        echo json_encode([
                            'success' => true,
                            'message' => 'Login berhasil'
                        ]);
                    } else {
                        http_response_code(401);
                        echo json_encode([
                            'success' => false,
                            'message' => 'Password salah'
                        ]);
                    }
                } else {
                    http_response_code(400);
                    echo json_encode([
                        'success' => false,
                        'message' => 'Password diperlukan'
                    ]);
                }
            } elseif ($input['action'] === 'logout') {
                $auth->logout();
                echo json_encode([
                    'success' => true,
                    'message' => 'Logout berhasil'
                ]);
            }
        }
        break;
        
    case 'GET':
        if ($auth->isAuthenticated()) {
            echo json_encode([
                'authenticated' => true,
                'login_time' => $_SESSION['login_time'] ?? null
            ]);
        } else {
            echo json_encode([
                'authenticated' => false
            ]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
?>

