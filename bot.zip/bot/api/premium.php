<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . 
'/../config/auth.php';
require_once __DIR__ . 
'/../config/database.php';

$auth = new Auth();
$auth->requireAuth();

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $premiumUsers = $db->readBotData('premiumUsers.json');
        $formattedUsers = [];
        
        foreach ($premiumUsers as $userId => $userData) {
            $formattedUsers[] = [
                'id' => $userId,
                'expires' => $userData['expires'] ?? null,
                'added_date' => $userData['added_date'] ?? null,
                'status' => (isset($userData['expires']) && $userData['expires'] > time()) ? 'active' : 'expired'
            ];
        }
        
        echo json_encode([
            'success' => true,
            'data' => $formattedUsers,
            'count' => count($formattedUsers)
        ]);
        break;
        
    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (isset($input['user_id']) && isset($input['duration'])) {
            $userId = $input['user_id'];
            $duration = intval($input['duration']);
            $expiresAt = time() + ($duration * 24 * 60 * 60); // Convert days to seconds
            
            $premiumUsers = $db->readBotData('premiumUsers.json');
            $premiumUsers[$userId] = [
                'expires' => $expiresAt,
                'added_date' => time(),
                'duration_days' => $duration
            ];
            
            if ($db->writeBotData('premiumUsers.json', $premiumUsers)) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Premium user berhasil ditambahkan',
                    'data' => [
                        'user_id' => $userId,
                        'expires' => $expiresAt,
                        'duration_days' => $duration
                    ]
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Gagal menyimpan data premium user'
                ]);
            }
        } else {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'User ID dan duration diperlukan'
            ]);
        }
        break;
        
    case 'DELETE':
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (isset($input['user_id'])) {
            $userId = $input['user_id'];
            $premiumUsers = $db->readBotData('premiumUsers.json');
            
            if (isset($premiumUsers[$userId])) {
                unset($premiumUsers[$userId]);
                
                if ($db->writeBotData('premiumUsers.json', $premiumUsers)) {
                    echo json_encode([
                        'success' => true,
                        'message' => 'Premium user berhasil dihapus'
                    ]);
                } else {
                    http_response_code(500);
                    echo json_encode([
                        'success' => false,
                        'message' => 'Gagal menghapus premium user'
                    ]);
                }
            } else {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'message' => 'Premium user tidak ditemukan'
                ]);
            }
        } else {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'User ID diperlukan'
            ]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
?>

