<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . 
'/../config/auth.php';
require_once __DIR__ . 
'/../config/database.php';

$auth = new Auth();
$auth->requireAuth();

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $configContent = $db->readBotConfig();
        
        // Extract BOT_TOKEN and GOOGLE_AI_API_KEY from config.js
        $botToken = '';
        $googleAiKey = '';
        
        if (preg_match('/BOT_TOKEN:\s*["\']([^"\']+)["\']/', $configContent, $matches)) {
            $botToken = $matches[1];
        }
        
        if (preg_match('/GOOGLE_AI_API_KEY:\s*["\']([^"\']+)["\']/', $configContent, $matches)) {
            $googleAiKey = $matches[1];
        }
        
        echo json_encode([
            'success' => true,
            'data' => [
                'bot_token' => $botToken ? substr($botToken, 0, 10) . '...' : '',
                'google_ai_key' => $googleAiKey ? substr($googleAiKey, 0, 10) . '...' : '',
                'bot_token_full' => $botToken,
                'google_ai_key_full' => $googleAiKey
            ]
        ]);
        break;
        
    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (isset($input['bot_token']) || isset($input['google_ai_key'])) {
            $configContent = $db->readBotConfig();
            
            if (isset($input['bot_token']) && !empty($input['bot_token'])) {
                $configContent = preg_replace(
                    '/BOT_TOKEN:\s*["\'][^"\']*["\']/',
                    'BOT_TOKEN: "' . $input['bot_token'] . '"',
                    $configContent
                );
            }
            
            if (isset($input['google_ai_key']) && !empty($input['google_ai_key'])) {
                $configContent = preg_replace(
                    '/GOOGLE_AI_API_KEY:\s*["\'][^"\']*["\']/',
                    'GOOGLE_AI_API_KEY: "' . $input['google_ai_key'] . '"',
                    $configContent
                );
            }
            
            if ($db->writeBotConfig($configContent)) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Konfigurasi berhasil disimpan'
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Gagal menyimpan konfigurasi'
                ]);
            }
        } else {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Tidak ada konfigurasi yang diubah'
            ]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
?>

