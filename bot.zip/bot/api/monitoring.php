<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . 
'/../config/auth.php';
require_once __DIR__ . 
'/../config/database.php';

$auth = new Auth();
$auth->requireAuth();

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Get bot process status
        $botStatus = 'offline';
        $botPid = null;
        
        // Check if bot process is running
        exec("pgrep -f 'node.*main.js'", $output, $returnCode);
        if ($returnCode === 0 && !empty($output)) {
            $botStatus = 'online';
            $botPid = $output[0];
        }
        
        // Get system resources
        $cpuUsage = 0;
        $memoryUsage = 0;
        
        // Get CPU usage
        exec("top -bn1 | grep 'Cpu(s)' | awk '{print $2}' | cut -d'%' -f1", $cpuOutput);
        if (!empty($cpuOutput)) {
            $cpuUsage = floatval($cpuOutput[0]);
        }
        
        // Get memory usage
        exec("free | grep Mem | awk '{printf \"%.1f\", $3/$2 * 100.0}'", $memOutput);
        if (!empty($memOutput)) {
            $memoryUsage = floatval($memOutput[0]);
        }
        
        // Get bot uptime (if running)
        $uptime = 0;
        if ($botPid) {
            exec("ps -o etime= -p $botPid 2>/dev/null", $uptimeOutput);
            if (!empty($uptimeOutput)) {
                $uptimeStr = trim($uptimeOutput[0]);
                // Convert uptime string to seconds
                $uptime = parseUptime($uptimeStr);
            }
        }
        
        // Get user activity data
        $userActivity = $db->readBotData('userActivity.json');
        $totalUsers = count($userActivity);
        
        // Get premium users count
        $premiumUsers = $db->readBotData('premiumUsers.json');
        $activePremiumCount = 0;
        foreach ($premiumUsers as $userData) {
            if (isset($userData['expires']) && $userData['expires'] > time()) {
                $activePremiumCount++;
            }
        }
        
        // Get messages today (mock data for now)
        $messagesToday = rand(50, 200);
        
        // Get recent activity logs
        $activityLogs = [];
        if (file_exists(__DIR__ . '/../../bot/logs/activity.log')) {
            $logContent = file_get_contents(__DIR__ . '/../../bot/logs/activity.log');
            $logLines = array_slice(explode("\n", $logContent), -10);
            foreach ($logLines as $line) {
                if (!empty(trim($line))) {
                    $activityLogs[] = [
                        'timestamp' => time() - rand(0, 3600),
                        'message' => trim($line)
                    ];
                }
            }
        } else {
            // Mock activity logs
            $activityLogs = [
                ['timestamp' => time() - 300, 'message' => 'Bot started successfully'],
                ['timestamp' => time() - 600, 'message' => 'User 123456789 sent message'],
                ['timestamp' => time() - 900, 'message' => 'Premium user added: 987654321'],
                ['timestamp' => time() - 1200, 'message' => 'API configuration updated'],
                ['timestamp' => time() - 1500, 'message' => 'System health check passed']
            ];
        }
        
        echo json_encode([
            'success' => true,
            'data' => [
                'bot_status' => $botStatus,
                'bot_pid' => $botPid,
                'uptime' => $uptime,
                'system' => [
                    'cpu_usage' => $cpuUsage,
                    'memory_usage' => $memoryUsage
                ],
                'stats' => [
                    'total_users' => $totalUsers,
                    'premium_users' => $activePremiumCount,
                    'messages_today' => $messagesToday
                ],
                'activity_logs' => $activityLogs
            ]
        ]);
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}

function parseUptime($uptimeStr) {
    // Parse uptime string like "01:23:45" or "1-02:34:56"
    $parts = explode('-', $uptimeStr);
    $days = 0;
    $timeStr = $uptimeStr;
    
    if (count($parts) > 1) {
        $days = intval($parts[0]);
        $timeStr = $parts[1];
    }
    
    $timeParts = explode(':', $timeStr);
    $hours = intval($timeParts[0]);
    $minutes = intval($timeParts[1]);
    $seconds = isset($timeParts[2]) ? intval($timeParts[2]) : 0;
    
    return ($days * 24 * 3600) + ($hours * 3600) + ($minutes * 60) + $seconds;
}
?>

