<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . 
'/../config/auth.php';
require_once __DIR__ . 
'/../config/database.php';

$auth = new Auth();
$auth->requireAuth();

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (isset($input['action'])) {
            $action = $input['action'];
            $botDir = __DIR__ . '/../../bot';
            
            switch ($action) {
                case 'start':
                    // Check if bot is already running
                    exec("pgrep -f 'node.*main.js'", $output, $returnCode);
                    if ($returnCode === 0 && !empty($output)) {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Bot sudah berjalan'
                        ]);
                        break;
                    }
                    
                    // Start bot in background
                    exec("cd $botDir && nohup node main.js > /dev/null 2>&1 & echo $!", $startOutput);
                    if (!empty($startOutput)) {
                        echo json_encode([
                            'success' => true,
                            'message' => 'Bot berhasil dijalankan',
                            'pid' => $startOutput[0]
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Gagal menjalankan bot'
                        ]);
                    }
                    break;
                    
                case 'stop':
                    // Stop bot process
                    exec("pkill -f 'node.*main.js'", $output, $returnCode);
                    if ($returnCode === 0) {
                        echo json_encode([
                            'success' => true,
                            'message' => 'Bot berhasil dihentikan'
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Bot tidak sedang berjalan atau gagal dihentikan'
                        ]);
                    }
                    break;
                    
                case 'restart':
                    // Stop bot first
                    exec("pkill -f 'node.*main.js'");
                    sleep(2); // Wait for process to stop
                    
                    // Start bot again
                    exec("cd $botDir && nohup node main.js > /dev/null 2>&1 & echo $!", $restartOutput);
                    if (!empty($restartOutput)) {
                        echo json_encode([
                            'success' => true,
                            'message' => 'Bot berhasil direstart',
                            'pid' => $restartOutput[0]
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Gagal merestart bot'
                        ]);
                    }
                    break;
                    
                case 'maintenance':
                    $enabled = isset($input['enabled']) ? $input['enabled'] : false;
                    
                    // Update maintenance mode in bot config or data
                    $maintenanceData = [
                        'maintenance_mode' => $enabled,
                        'message' => '⛔ Maaf, bot sedang dalam perbaikan. Mohon tunggu hingga selesai!',
                        'updated_at' => time()
                    ];
                    
                    if ($db->writeJSON('maintenance.json', $maintenanceData)) {
                        echo json_encode([
                            'success' => true,
                            'message' => $enabled ? 'Mode maintenance diaktifkan' : 'Mode maintenance dinonaktifkan',
                            'maintenance_mode' => $enabled
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Gagal mengubah mode maintenance'
                        ]);
                    }
                    break;
                    
                default:
                    http_response_code(400);
                    echo json_encode([
                        'success' => false,
                        'message' => 'Action tidak valid'
                    ]);
                    break;
            }
        } else {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Action diperlukan'
            ]);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
?>

