#!/bin/bash

# Rizky-AI Bot Dashboard Stop Script
echo "==================================="
echo "   Stopping Rizky-AI Bot System   "
echo "==================================="

# Stop web dashboard
echo "Stopping web dashboard..."
pkill -f "php -S.*8080"
if [ $? -eq 0 ]; then
    echo "✅ Dashboard stopped"
else
    echo "ℹ️  Dashboard was not running"
fi

# Stop Telegram bot
echo "Stopping Telegram bot..."
pkill -f "node.*main.js"
if [ $? -eq 0 ]; then
    echo "✅ Bot stopped"
else
    echo "ℹ️  Bot was not running"
fi

echo ""
echo "==================================="
echo "    All services have been stopped"
echo "==================================="
echo "To start again, run: ./start.sh"

