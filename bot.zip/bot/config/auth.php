<?php
session_start();

class Auth {
    private $password = 'Rizky-Ai';
    
    public function login($inputPassword) {
        if ($inputPassword === $this->password) {
            $_SESSION['authenticated'] = true;
            $_SESSION['login_time'] = time();
            return true;
        }
        return false;
    }
    
    public function logout() {
        session_destroy();
        return true;
    }
    
    public function isAuthenticated() {
        return isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true;
    }
    
    public function requireAuth() {
        if (!$this->isAuthenticated()) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
    }
}
?>

