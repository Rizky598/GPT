<?php
class Database {
    private $dataDir;
    
    public function __construct() {
        $this->dataDir = __DIR__ . '/../data/';
        if (!is_dir($this->dataDir)) {
            mkdir($this->dataDir, 0755, true);
        }
    }
    
    public function readJSON($filename) {
        $filepath = $this->dataDir . $filename;
        if (file_exists($filepath)) {
            $content = file_get_contents($filepath);
            return json_decode($content, true);
        }
        return [];
    }
    
    public function writeJSON($filename, $data) {
        $filepath = $this->dataDir . $filename;
        return file_put_contents($filepath, json_encode($data, JSON_PRETTY_PRINT));
    }
    
    public function readBotData($filename) {
        $botDataPath = __DIR__ . '/../../bot/lib/' . $filename;
        if (file_exists($botDataPath)) {
            $content = file_get_contents($botDataPath);
            return json_decode($content, true);
        }
        return [];
    }
    
    public function writeBotData($filename, $data) {
        $botDataPath = __DIR__ . '/../../bot/lib/' . $filename;
        return file_put_contents($botDataPath, json_encode($data, JSON_PRETTY_PRINT));
    }
    
    public function readBotConfig() {
        $configPath = __DIR__ . '/../../bot/config.js';
        if (file_exists($configPath)) {
            return file_get_contents($configPath);
        }
        return '';
    }
    
    public function writeBotConfig($content) {
        $configPath = __DIR__ . '/../../bot/config.js';
        return file_put_contents($configPath, $content);
    }
}
?>

