<?php
// Simple PHP server to serve the dashboard application
$port = 8080;
$host = '0.0.0.0';

// Set document root to frontend directory
$documentRoot = __DIR__;
// Start PHP built-in server
echo "Starting Rizky-AI Dashboard Server...\n";
echo "Server running at http://$host:$port\n";
echo "Document root: $documentRoot\n";
echo "Press Ctrl+C to stop the server\n\n";

// Change to frontend directory and start server
chdir($documentRoot);
exec("php -S $host:$port -t $documentRoot");
?>

