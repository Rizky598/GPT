// Global variables
let currentSection = 'overview';
let refreshInterval;
const API_BASE = "api";

// DOM elements
const loginScreen = document.getElementById('login-screen');
const dashboardScreen = document.getElementById('dashboard-screen');
const loginForm = document.getElementById('login-form');
const errorMessage = document.getElementById('error-message');
const logoutBtn = document.getElementById('logout-btn');

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    checkAuthStatus();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Login form
    loginForm.addEventListener('submit', handleLogin);
    
    // Logout button
    logoutBtn.addEventListener('click', handleLogout);
    
    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function() {
            const section = this.dataset.section;
            switchSection(section);
        });
    });
    
    // Premium management
    document.getElementById('add-premium-btn').addEventListener('click', showAddPremiumModal);
    document.getElementById('refresh-premium-btn').addEventListener('click', loadPremiumUsers);
    document.getElementById('add-premium-form').addEventListener('submit', handleAddPremium);
    document.getElementById('cancel-premium').addEventListener('click', hideAddPremiumModal);
    
    // API configuration
    document.getElementById('toggle-token').addEventListener('click', togglePasswordVisibility);
    document.getElementById('toggle-ai-key').addEventListener('click', togglePasswordVisibility);
    document.getElementById('save-api-config').addEventListener('click', saveApiConfig);
    
    // Bot control
    document.getElementById('restart-bot').addEventListener('click', () => controlBot('restart'));
    document.getElementById('stop-bot').addEventListener('click', () => controlBot('stop'));
    document.getElementById('maintenance-toggle').addEventListener('change', toggleMaintenance);
    
    // Modal close
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });
    
    // Click outside modal to close
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
}

// Authentication functions
async function checkAuthStatus() {
    try {
        const response = await fetch(`${API_BASE}/auth.php`);
        const data = await response.json();
        
        if (data.authenticated) {
            showDashboard();
        } else {
            showLogin();
        }
    } catch (error) {
        console.error('Error checking auth status:', error);
        showLogin();
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(`${API_BASE}/auth.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'login',
                password: password
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showDashboard();
            errorMessage.style.display = 'none';
        } else {
            showError(data.message);
        }
    } catch (error) {
        console.error('Login error:', error);
        showError('Terjadi kesalahan saat login');
    }
}

async function handleLogout() {
    try {
        await fetch(`${API_BASE}/auth.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'logout'
            })
        });
        
        showLogin();
        clearInterval(refreshInterval);
    } catch (error) {
        console.error('Logout error:', error);
    }
}

function showLogin() {
    loginScreen.style.display = 'flex';
    dashboardScreen.style.display = 'none';
    document.getElementById('password').value = '';
}

function showDashboard() {
    loginScreen.style.display = 'none';
    dashboardScreen.style.display = 'block';
    loadDashboardData();
    startAutoRefresh();
}

function showError(message) {
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
}

// Navigation functions
function switchSection(section) {
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`[data-section="${section}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(`${section}-section`).classList.add('active');
    
    currentSection = section;
    
    // Load section-specific data
    switch (section) {
        case 'overview':
            loadOverviewData();
            break;
        case 'premium':
            loadPremiumUsers();
            break;
        case 'api':
            loadApiConfig();
            break;
        case 'monitoring':
            loadMonitoringData();
            break;
        case 'settings':
            loadSettings();
            break;
    }
}

// Dashboard data loading
async function loadDashboardData() {
    await loadOverviewData();
    await loadBotStatus();
}

async function loadOverviewData() {
    try {
        const response = await fetch(`${API_BASE}/monitoring.php`);
        const data = await response.json();
        
        if (data.success) {
            const stats = data.data.stats;
            document.getElementById('total-users').textContent = stats.total_users;
            document.getElementById('premium-count').textContent = stats.premium_users;
            document.getElementById('messages-today').textContent = stats.messages_today;
            document.getElementById('uptime').textContent = formatUptime(data.data.uptime);
        }
    } catch (error) {
        console.error('Error loading overview data:', error);
    }
}

async function loadBotStatus() {
    try {
        const response = await fetch(`${API_BASE}/monitoring.php`);
        const data = await response.json();
        
        if (data.success) {
            const status = data.data.bot_status;
            const statusElement = document.getElementById('status-text');
            const statusIndicator = document.querySelector('.status-indicator');
            
            statusElement.textContent = status === 'online' ? 'Online' : 'Offline';
            statusIndicator.style.color = status === 'online' ? '#27ae60' : '#e74c3c';
        }
    } catch (error) {
        console.error('Error loading bot status:', error);
    }
}

// Premium users management
async function loadPremiumUsers() {
    try {
        const response = await fetch(`${API_BASE}/premium.php`);
        const data = await response.json();
        
        if (data.success) {
            displayPremiumUsers(data.data);
        }
    } catch (error) {
        console.error('Error loading premium users:', error);
    }
}

function displayPremiumUsers(users) {
    const premiumList = document.getElementById('premium-list');
    
    if (users.length === 0) {
        premiumList.innerHTML = '<div style="text-align: center; padding: 40px; color: #666;">Tidak ada premium user</div>';
        return;
    }
    
    premiumList.innerHTML = users.map(user => `
        <div class="premium-item">
            <div class="premium-info">
                <h4>User ID: ${user.id}</h4>
                <p>Status: <span style="color: ${user.status === 'active' ? '#27ae60' : '#e74c3c'}">${user.status}</span></p>
                <p>Expires: ${user.expires ? new Date(user.expires * 1000).toLocaleDateString('id-ID') : 'N/A'}</p>
            </div>
            <div class="premium-actions">
                <button class="btn btn-danger btn-small" onclick="removePremiumUser('${user.id}')">
                    <i class="fas fa-trash"></i>
                    Remove
                </button>
            </div>
        </div>
    `).join('');
}

function showAddPremiumModal() {
    document.getElementById('add-premium-modal').style.display = 'block';
}

function hideAddPremiumModal() {
    document.getElementById('add-premium-modal').style.display = 'none';
    document.getElementById('add-premium-form').reset();
}

async function handleAddPremium(e) {
    e.preventDefault();
    
    const userId = document.getElementById('user-id').value;
    const duration = document.getElementById('duration').value;
    
    try {
        const response = await fetch(`${API_BASE}/premium.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId,
                duration: parseInt(duration)
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            hideAddPremiumModal();
            loadPremiumUsers();
            showNotification('Premium user berhasil ditambahkan', 'success');
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('Error adding premium user:', error);
        showNotification('Terjadi kesalahan saat menambah premium user', 'error');
    }
}

async function removePremiumUser(userId) {
    if (!confirm('Apakah Anda yakin ingin menghapus premium user ini?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/premium.php`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadPremiumUsers();
            showNotification('Premium user berhasil dihapus', 'success');
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('Error removing premium user:', error);
        showNotification('Terjadi kesalahan saat menghapus premium user', 'error');
    }
}

// API configuration
async function loadApiConfig() {
    try {
        const response = await fetch(`${API_BASE}/config.php`);
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('bot-token').value = data.data.bot_token_full;
            document.getElementById('google-ai-key').value = data.data.google_ai_key_full;
        }
    } catch (error) {
        console.error('Error loading API config:', error);
    }
}

async function saveApiConfig() {
    const botToken = document.getElementById('bot-token').value;
    const googleAiKey = document.getElementById('google-ai-key').value;
    
    try {
        const response = await fetch(`${API_BASE}/config.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                bot_token: botToken,
                google_ai_key: googleAiKey
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Konfigurasi berhasil disimpan', 'success');
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('Error saving API config:', error);
        showNotification('Terjadi kesalahan saat menyimpan konfigurasi', 'error');
    }
}

function togglePasswordVisibility(e) {
    const button = e.target.closest('button');
    const input = button.previousElementSibling;
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Monitoring
async function loadMonitoringData() {
    try {
        const response = await fetch(`${API_BASE}/monitoring.php`);
        const data = await response.json();
        
        if (data.success) {
            // Update system resources
            const system = data.data.system;
            document.getElementById('cpu-progress').style.width = system.cpu_usage + '%';
            document.getElementById('cpu-percent').textContent = system.cpu_usage.toFixed(1) + '%';
            document.getElementById('memory-progress').style.width = system.memory_usage + '%';
            document.getElementById('memory-percent').textContent = system.memory_usage.toFixed(1) + '%';
            
            // Update activity logs
            displayActivityLogs(data.data.activity_logs);
        }
    } catch (error) {
        console.error('Error loading monitoring data:', error);
    }
}

function displayActivityLogs(logs) {
    const activityLog = document.getElementById('activity-log');
    
    if (logs.length === 0) {
        activityLog.innerHTML = '<div style="text-align: center; padding: 20px; color: #666;">Tidak ada log aktivitas</div>';
        return;
    }
    
    activityLog.innerHTML = logs.map(log => `
        <div class="activity-item">
            <div class="activity-time">${new Date(log.timestamp * 1000).toLocaleString('id-ID')}</div>
            <div>${log.message}</div>
        </div>
    `).join('');
}

// Bot control
async function controlBot(action) {
    try {
        const response = await fetch(`${API_BASE}/bot-control.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: action
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(data.message, 'success');
            setTimeout(() => {
                loadBotStatus();
                loadOverviewData();
            }, 2000);
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('Error controlling bot:', error);
        showNotification('Terjadi kesalahan saat mengontrol bot', 'error');
    }
}

async function toggleMaintenance(e) {
    const enabled = e.target.checked;
    
    try {
        const response = await fetch(`${API_BASE}/bot-control.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'maintenance',
                enabled: enabled
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(data.message, 'success');
        } else {
            showNotification(data.message, 'error');
            e.target.checked = !enabled; // Revert toggle
        }
    } catch (error) {
        console.error('Error toggling maintenance:', error);
        showNotification('Terjadi kesalahan saat mengubah mode maintenance', 'error');
        e.target.checked = !enabled; // Revert toggle
    }
}

// Settings
async function loadSettings() {
    // Load maintenance mode status
    try {
        const response = await fetch(`${API_BASE}/../data/maintenance.json`);
        if (response.ok) {
            const data = await response.json();
            document.getElementById('maintenance-toggle').checked = data.maintenance_mode || false;
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

// Utility functions
function formatUptime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
        max-width: 300px;
    `;
    
    // Set background color based on type
    switch (type) {
        case 'success':
            notification.style.backgroundColor = '#27ae60';
            break;
        case 'error':
            notification.style.backgroundColor = '#e74c3c';
            break;
        default:
            notification.style.backgroundColor = '#667eea';
    }
    
    // Add to document
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Auto refresh
function startAutoRefresh() {
    refreshInterval = setInterval(() => {
        if (currentSection === 'overview') {
            loadOverviewData();
        } else if (currentSection === 'monitoring') {
            loadMonitoringData();
        }
        loadBotStatus();
    }, 30000); // Refresh every 30 seconds
}

// Add CSS for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

