const { Telegraf, Markup } = require("telegraf");
const fs = require("fs");
const chalk = require("chalk");
const moment = require("moment-timezone");
const fetch = require("node-fetch");
const axios = require("axios");
const cheerio = require("cheerio");
const FormData = require("form-data");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const Jimp = require("jimp");
const ffmpeg = require("fluent-ffmpeg");
const path = require("path");
const config = require("./config");
const https = require("https");

// --- Inisialisasi Bot Telegram dan AI ---
const bot = new Telegraf(config.BOT_TOKEN);
const genAI = new GoogleGenerativeAI(config.GOOGLE_AI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// --- Direktori untuk Riwayat Chat AI ---
const chatHistoryPath = "./chat_history";
if (!fs.existsSync(chatHistoryPath)) {
    fs.mkdirSync(chatHistoryPath, { recursive: true });
}

// --- Variabel Global ---
let maintenanceConfig = {
    maintenance_mode: false,
    message: "⛔ Maaf, bot sedang dalam perbaikan. Mohon tunggu hingga selesai!",
};
let premiumUsers = {};
let adminList = [];
let ownerList = [];
let userActivity = {};
let ownerataubukan;
let adminataubukan;
let Premiumataubukan;

// --- Fungsi Bantuan ---
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// --- Fungsi untuk Mengecek Owner ---
const isOwner = (userId) => {
    userId = userId.toString();
    ownerataubukan = ownerList.includes(userId) ? "✅" : "❌";
    return ownerList.includes(userId);
};

const OWNER_ID = (userId) => {
    return config.allowedDevelopers.includes(userId.toString());
};

// --- Fungsi untuk Mengecek Admin ---
const isAdmin = (userId) => {
    userId = userId.toString();
    adminataubukan = adminList.includes(userId) ? "✅" : "❌";
    return adminList.includes(userId);
};

// --- Fungsi untuk Menambahkan/Menghapus Admin ---
const addAdmin = (userId) => {
    userId = userId.toString();
    if (!adminList.includes(userId)) {
        adminList.push(userId);
        saveAdmins();
    }
};

const removeAdmin = (userId) => {
    userId = userId.toString();
    adminList = adminList.filter((id) => id !== userId);
    saveAdmins();
};

const saveAdmins = () => {
    fs.writeFileSync("./lib/admins.json", JSON.stringify(adminList));
};

const loadAdmins = () => {
    try {
        const data = fs.readFileSync("./lib/admins.json");
        adminList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red("Gagal memuat daftar admin:"), error);
        adminList = [];
    }
};

// --- Fungsi untuk Menambahkan/Menghapus Owner ---
const addOwner = (userId) => {
    userId = userId.toString();
    if (!ownerList.includes(userId)) {
        ownerList.push(userId);
        saveOwnerList();
    }
};

const removeOwner = (userId) => {
    userId = userId.toString();
    ownerList = ownerList.filter((id) => id !== userId);
    saveOwnerList();
};

const saveOwnerList = () => {
    fs.writeFileSync("./lib/owners.json", JSON.stringify(ownerList));
};

const loadOwnerList = () => {
    try {
        const data = fs.readFileSync("./lib/owners.json");
        ownerList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red("Gagal memuat daftar owner:"), error);
        ownerList = [];
    }
};

// --- Fungsi untuk Premium User ---
const addPremiumUser = (userId, durationDays) => {
    userId = userId.toString();
    const expirationDate = moment().tz("Asia/Jakarta").add(durationDays, "days");
    premiumUsers[userId] = {
        expired: expirationDate.format("YYYY-MM-DD HH:mm:ss"),
    };
    savePremiumUsers();
};

const removePremiumUser = (userId) => {
    userId = userId.toString();
    delete premiumUsers[userId];
    savePremiumUsers();
};

const isPremiumUser = (userId) => {
    userId = userId.toString();
    const userData = premiumUsers[userId];
    if (!userData) {
        Premiumataubukan = "❌";
        return false;
    }
    const now = moment().tz("Asia/Jakarta");
    const expirationDate = moment(userData.expired, "YYYY-MM-DD HH:mm:ss").tz("Asia/Jakarta");
    Premiumataubukan = now.isBefore(expirationDate) ? "✅" : "❌";
    return now.isBefore(expirationDate);
};

const savePremiumUsers = () => {
    fs.writeFileSync("./lib/premiumUsers.json", JSON.stringify(premiumUsers));
};

const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync("./lib/premiumUsers.json");
        premiumUsers = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red("Gagal memuat data user premium:"), error);
        premiumUsers = {};
    }
};

// --- Fungsi untuk Mencatat Aktivitas Pengguna ---
const recordUserActivity = (userId, userNickname) => {
    const now = moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss");
    userActivity[userId] = {
        nickname: userNickname,
        last_seen: now,
    };
    fs.writeFileSync("./userActivity.json", JSON.stringify(userActivity));
};

const loadUserActivity = () => {
    try {
        const data = fs.readFileSync("./userActivity.json");
        userActivity = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red("Gagal memuat aktivitas pengguna:"), error);
        userActivity = {};
    }
};

// --- Fungsi untuk Mendapatkan Waktu Uptime ---
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    return `${hours}h ${minutes}m ${seconds}s`;
};

// --- Middleware untuk Maintenance ---
const checkMaintenance = async (ctx, next) => {
    let userId, userNickname;
    if (ctx.from) {
        userId = ctx.from.id.toString();
        userNickname = ctx.from.first_name || userId;
        recordUserActivity(userId, userNickname);
    }
    if (maintenanceConfig.maintenance_mode && !OWNER_ID(ctx.from.id)) {
        const escapedMessage = maintenanceConfig.message.replace(/\*/g, "\\*");
        return await ctx.replyWithMarkdown(escapedMessage);
    }
    await next();
};

// --- Middleware untuk Premium ---
const checkPremium = async (ctx, next) => {
    if (isPremiumUser(ctx.from.id)) {
        await next();
    } else {
        await ctx.reply("❌ Maaf, Anda perlu status premium untuk menggunakan fitur ini.");
    }
};

// --- Fungsi Fitur Seru-seruan ---
async function sendAnimeMenu(ctx) {
    const menuText = `
*Anime Menu by ${config.botName}* 🎌  
Pilih kategori anime favoritmu!  

🌟 *SFW (Safe for Work)*  
• /animeneko - Gambar kucing imut  
• /animewaifu - Waifu idamanmu  

🔞 *NSFW (18+)*  
• /animehentai  
• /animemilf  
• /animeass  
• /animeboobs  
• /animeero  
• /animepussy  
• /animefeet  
• /animeyuri  
• /animetrap  
• /animeblowjob  
• /animecum  
• /animehandjob  
• /animeahegao  
• /animeoral  
• /animegangbang  
• /animeglasses  
• /animethighs  
• /animeuniform  
• /animebondage  
• /animecuckold  
• /animefemdom  
• /animeloli  
• /animeshoto  
• /animesquirting  
• /animeteacher  
• /animetentacles  
• /animeyaoi  

⚠️ Gunakan dengan bijak! Konten NSFW hanya untuk 18+.
    `;
    await ctx.replyWithMarkdown(menuText);
}

async function getSFWImage(category) {
    try {
        const response = await fetch(`https://api.waifu.pics/sfw/${category}`);
        const data = await response.json();
        return data.url;
    } catch (error) {
        console.error(`Error fetching SFW image for ${category}:`, error);
        return null;
    }
}

async function getNSFWImage(category) {
    try {
        // Daftar kategori NSFW yang valid berdasarkan dokumentasi waifu.pics
        const validNSFWCategories = [
            "waifu", "neko", "trap", "blowjob"
        ];
        
        // Mapping kategori yang tidak tersedia ke kategori yang tersedia
        const categoryMapping = {
            "hentai": "waifu",
            "milf": "waifu", 
            "loli": "neko",
            "ass": "waifu",
            "boobs": "waifu",
            "ero": "waifu",
            "pussy": "waifu",
            "feet": "waifu",
            "yuri": "waifu",
            "cum": "waifu",
            "handjob": "waifu",
            "ahegao": "waifu",
            "oral": "blowjob",
            "gangbang": "waifu",
            "glasses": "waifu",
            "thighs": "waifu",
            "uniform": "waifu",
            "bondage": "waifu",
            "cuckold": "waifu",
            "femdom": "waifu",
            "shoto": "neko",
            "squirting": "waifu",
            "teacher": "waifu",
            "tentacles": "waifu",
            "yaoi": "trap"
        };
        
        // Gunakan mapping jika kategori tidak tersedia langsung
        const actualCategory = categoryMapping[category] || category;
        
        // Validasi kategori
        if (!validNSFWCategories.includes(actualCategory)) {
            console.error(`Invalid NSFW category: ${category} -> ${actualCategory}`);
            return null;
        }
        
        const response = await fetch(`https://api.waifu.pics/nsfw/${actualCategory}`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        return data.url;
    } catch (error) {
        console.error(`Error fetching NSFW image for ${category}:`, error);
        return null;
    }
}

async function handleTikTokCommand(ctx, url) {
    if (!url) {
        return await ctx.reply("Masukkan URL TikTok!");
    }
    try {
        const response = await fetch(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(url)}`);
        const data = await response.json();
        if (data.video?.noWatermark) {
            await ctx.replyWithVideo({ url: data.video.noWatermark }, { caption: "Video TikTok tanpa watermark!" });
        } else {
            await ctx.reply("Gagal mengunduh video TikTok.");
        }
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleSmemeCommand(ctx, text, quotedMessage) {
    if (!quotedMessage || !quotedMessage.photo) {
        return await ctx.reply("Reply gambar dengan teks untuk membuat meme!");
    }
    try {
        const photo = quotedMessage.photo[quotedMessage.photo.length - 1];
        const imageBuffer = await ctx.telegram.getFileLink(photo.file_id).then((url) => fetch(url).then((res) => res.buffer()));
        const image = await Jimp.read(imageBuffer);
        const font = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
        image.print(font, 10, 10, text, image.bitmap.width - 20);
        const buffer = await image.getBufferAsync(Jimp.MIME_JPEG);

        const form = new FormData();
        form.append("image", buffer, "meme.jpg");
        const response = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: "POST",
            body: form,
        });
        const data = await response.json();

        if (data.data?.url) {
            await ctx.replyWithPhoto({ url: data.data.url }, { caption: "Meme kamu jadi!" });
        } else {
            await ctx.reply("Gagal mengunggah meme.");
        }
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleVideoStickerCommand(ctx, quotedMessage) {
    if (!quotedMessage || !quotedMessage.video) {
        return await ctx.reply("Reply video untuk membuat stiker animasi!");
    }
    try {
        const video = quotedMessage.video;
        const videoBuffer = await ctx.telegram.getFileLink(video.file_id).then((url) => fetch(url).then((res) => res.buffer()));
        const tempInput = path.join("temp", `input-${Date.now()}.mp4`);
        const tempOutput = path.join("temp", `output-${Date.now()}.webp`);

        if (!fs.existsSync("temp")) {
            fs.mkdirSync("temp", { recursive: true });
        }

        fs.writeFileSync(tempInput, videoBuffer);

        await new Promise((resolve, reject) => {
            ffmpeg(tempInput)
                .outputOptions([
                    "-vf",
                    "scale=512:512:force_original_aspect_ratio=decrease,fps=15",
                    "-c:v",
                    "libwebp",
                    "-lossless",
                    "1",
                    "-loop",
                    "0",
                    "-t",
                    "10",
                ])
                .output(tempOutput)
                .on("end", resolve)
                .on("error", reject)
                .run();
        });

        const webpBuffer = fs.readFileSync(tempOutput);
        const form = new FormData();
        form.append("image", webpBuffer, "sticker.webp");
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: "POST",
            body: form,
        });
        const imgbbData = await imgbbResponse.json();

        if (imgbbData.data?.url) {
            await ctx.replyWithSticker({ url: imgbbData.data.url });
        } else {
            await ctx.reply("Gagal membuat stiker video.");
        }

        fs.unlinkSync(tempInput);
        fs.unlinkSync(tempOutput);
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleBratCommand(ctx, text) {
    if (!text) {
        return await ctx.reply("Masukkan teks untuk Brat Generator!");
    }
    
    // Cek apakah HF_API_KEY tersedia
    if (!config.HF_API_KEY || config.HF_API_KEY === "") {
        return await ctx.reply("❌ Fitur Brat Generator tidak tersedia. API key Hugging Face belum dikonfigurasi. Hubungi admin untuk mengaktifkan fitur ini.");
    }
    
    try {
        const response = await fetch("https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-3-medium", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${config.HF_API_KEY}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ inputs: `brat style: ${text}` }),
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const buffer = await response.buffer();

        const form = new FormData();
        form.append("image", buffer, "brat.jpg");
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: "POST",
            body: form,
        });
        const imgbbData = await imgbbResponse.json();

        if (imgbbData.data?.url) {
            await ctx.replyWithPhoto({ url: imgbbData.data.url }, { caption: `Brat style: ${text}` });
        } else {
            await ctx.reply("Gagal menghasilkan gambar Brat.");
        }
    } catch (error) {
        console.error("Error in handleBratCommand:", error);
        await ctx.reply(`❌ Terjadi kesalahan saat menghasilkan gambar Brat: ${error.message}`);
    }
}

async function handleBratVidCommand(ctx, text) {
    if (!text) {
        return await ctx.reply("Masukkan teks untuk Brat Video Generator!");
    }
    
    // Cek apakah RUNWAY_API_KEY tersedia
    if (!config.RUNWAY_API_KEY || config.RUNWAY_API_KEY === "") {
        return await ctx.reply("❌ Fitur Brat Video Generator tidak tersedia. API key RunwayML belum dikonfigurasi. Hubungi admin untuk mengaktifkan fitur ini.");
    }
    
    try {
        const response = await fetch("https://api.runwayml.com/v1/generations", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${config.RUNWAY_API_KEY}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ prompt: `brat style video: ${text}` }),
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();

        if (data.videoUrl) {
            await ctx.replyWithVideo({ url: data.videoUrl }, { caption: `Brat video: ${text}` });
        } else {
            await ctx.reply("Gagal menghasilkan video Brat.");
        }
    } catch (error) {
        console.error("Error in handleBratVidCommand:", error);
        await ctx.reply(`❌ Terjadi kesalahan saat menghasilkan video Brat: ${error.message}`);
    }
}

async function handleCekMatiCommand(ctx, url) {
    if (!url) {
        return await ctx.reply("Masukkan URL untuk cek status!");
    }
    try {
        const response = await fetch(url);
        if (response.ok) {
            await ctx.reply(`✅ Website ${url} aktif! Status: ${response.status}`);
        } else {
            await ctx.reply(`❌ Website ${url} mati atau bermasalah! Status: ${response.status}`);
        }
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleNpmSearchCommand(ctx, query) {
    if (!query) {
        return await ctx.reply("Masukkan nama paket NPM!");
    }
    try {
        const response = await fetch(`https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data.objects.length > 0) {
            const pkg = data.objects[0].package;
            await ctx.reply(`📦 *${pkg.name}*\nVersi: ${pkg.version}\nDeskripsi: ${pkg.description}\nLink: ${pkg.links.npm}`);
        } else {
            await ctx.reply("Paket NPM tidak ditemukan.");
        }
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleScreenshotCommand(ctx, url) {
    if (!url) {
        return await ctx.reply("Masukkan URL untuk screenshot!");
    }
    try {
        const response = await fetch(`https://api.screenshotmachine.com?key=${config.SCREENSHOTMACHINE_API_KEY}&url=${encodeURIComponent(url)}&dimension=1024x768`);
        const buffer = await response.buffer();

        const form = new FormData();
        form.append("image", buffer, "screenshot.jpg");
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: "POST",
            body: form,
        });
        const imgbbData = await imgbbResponse.json();

        if (imgbbData.data?.url) {
            await ctx.replyWithPhoto({ url: imgbbData.data.url }, { caption: `Screenshot dari ${url}` });
        } else {
            await ctx.reply("Gagal mengambil screenshot.");
        }
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleCuacaCommand(ctx, city) {
    if (!city) {
        return await ctx.reply("Masukkan nama kota!");
    }
    try {
        const response = await fetch(`http://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${config.WEATHER_API_KEY}&units=metric`);
        const data = await response.json();
        if (data.cod === 200) {
            await ctx.reply(`☁️ Cuaca di ${city}:\nSuhu: ${data.main.temp}°C\nKelembapan: ${data.main.humidity}%\nDeskripsi: ${data.weather[0].description}`);
        } else {
            await ctx.reply(`Kota ${city} tidak ditemukan.`);
        }
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleKopiCommand(ctx) {
    try {
        await ctx.reply("☕ Kopi telah diseduh! Nikmati aroma virtualnya!");
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleAICommand(ctx, query) {
    if (!query) {
        return await ctx.reply("Masukkan pertanyaan untuk AI!");
    }
    try {
        const userId = ctx.from.id.toString();
        const historyFile = path.join(chatHistoryPath, `${userId}.json`);
        let history = [];
        if (fs.existsSync(historyFile)) {
            history = JSON.parse(fs.readFileSync(historyFile));
        }

        const chat = model.startChat({ history });
        const result = await chat.sendMessage(query);
        const response = await result.response;

        history.push({ role: "user", parts: [{ text: query }] });
        history.push({ role: "model", parts: [{ text: response.text() }] });
        fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));

        await ctx.reply(response.text());
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleResetAICommand(ctx) {
    try {
        const userId = ctx.from.id.toString();
        const historyFile = path.join(chatHistoryPath, `${userId}.json`);
        if (fs.existsSync(historyFile)) {
            fs.unlinkSync(historyFile);
            await ctx.reply("🧹 Riwayat AI telah direset!");
        } else {
            await ctx.reply("Tidak ada riwayat AI untuk direset.");
        }
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

async function handleStickerCommand(ctx, quotedMessage) {
    if (!quotedMessage || !quotedMessage.photo) {
        return await ctx.reply("Reply gambar untuk membuat stiker!");
    }
    try {
        const photo = quotedMessage.photo[quotedMessage.photo.length - 1];
        const imageBuffer = await ctx.telegram.getFileLink(photo.file_id).then((url) => fetch(url).then((res) => res.buffer()));
        const image = await Jimp.read(imageBuffer);
        image.resize(512, 512).quality(80);
        const buffer = await image.getBufferAsync(Jimp.MIME_JPEG);

        const form = new FormData();
        form.append("image", buffer, "sticker.jpg");
        const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: "POST",
            body: form,
        });
        const imgbbData = await imgbbResponse.json();

        if (imgbbData.data?.url) {
            await ctx.replyWithSticker({ url: imgbbData.data.url });
        } else {
            await ctx.reply("Gagal membuat stiker.");
        }
    } catch (error) {
        await ctx.reply(`Error: ${error.message}`);
    }
}

// --- Inisialisasi Bot ---
(async () => {
    console.log(chalk.red.bold(`  
👑 𝐑𝐈𝐙𝐊𝐘 𝐀𝐏𝐏 𝐒𝐓𝐎𝐑𝐄 👑`));

    if (!config.BOT_TOKEN || config.BOT_TOKEN === "" || config.BOT_TOKEN === "YOUR_BOT_TOKEN_HERE") {
        console.log(chalk.red.bold(`
╭═══════════════════════════════════════❍
┃ Bot Token Tidak ditemukan atau tidak benar
┃ Silakan Buat BOT_TOKEN di @BotFather
╰═══════════════════════════════════════❍`));
        process.exit(1);
    }

    console.log(chalk.white.bold(`
╭──「 𝗦𝗧𝗔𝗧𝗨𝗦 」
┃ ${chalk.cyanBright.bold("LOADING DATABASE")}
╰─────────────────❍`));

    try {
        loadPremiumUsers();
       loadAdmins();
        loadOwnerList();
        loadUserActivity();

        console.log(chalk.white.bold(`
╭──「 𝗦𝗧_A𝗧𝗨𝗦� 」
┃ ${chalk.greenBright.bold("SYSTEM READY !!")}
╰─────────────────❍`));
    } catch (error) {
        console.error(chalk.red.bold(`
╭═══════════════════════════════════════❍
┃ Terjadi kesalahan saat inisialisasi:
┃ ${error.message}
╰═══════════════════════════════════════❍`));
        process.exit(1);
    }
})();

// --- Command Handlers ---
bot.start(async (ctx) => {
    await ctx.telegram.sendChatAction(ctx.chat.id, "typing");
    const waktuRunPanel = getUptime();
    const mainMenuMessage = `\`\`\`
╭━𓊈 𝐑𝐈𝐙𝐊𝐘 𝐀𝐏𝐏 𝐒𝐓𝐎𝐑𝐄 𓊉━═╣
║𝙱𝙾𝚃 𝙽𝙰𝙼𝙴 : ${config.botName}
┃𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0
║𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━━━━━━━━═╣
╭━━━━━━━━━━━━━━━━━━━━━
┃ᴅɪʟᴀʀᴀɴɢ ꜱᴘᴀᴍ
┃ᴅɪʟᴀʀᴀɴɢ ʙᴇʀᴋᴀᴛᴀ ᴋᴀꜱᴀʀ
┃ᴅɪʟᴀʀᴀɴɢ ᴍᴇɴɢɪʀɪᴍ 18+
┃ᴅɪʟᴀʀᴀɴɢ ʀᴀꜱɪꜱ
┃ᴅɪʟᴀʀᴀɴɢ ꜱᴘᴀᴍ ʙᴏᴛ
┃ᴅɪʟᴀʀᴀɴɢ ᴍᴇɴɢɪʀɪᴍ ʟɪɴᴋ ɴɢɢᴀᴋ ᴊᴇʟᴀꜱ
┃ᴅɪʟᴀʀᴀɴɢ ᴘʀᴏᴍᴏꜱɪ
╰━━━━━━━━━━━━━━━━━━━━━
╭────────────────────
│[ 𝚂𝙴𝙻𝙴𝙲𝚃 𝙱𝚄𝚃𝚃𝙾𝙽 𝙼𝙴𝙽𝚄 ]
╰────────────────────
\`\`\``;

    const mainKeyboard = [
        [
            { text: "『 ᴏᴡɴᴇʀ ᴍᴇɴᴜ 』", callback_data: "owner_menu" },
            { text: "『 ᴀʟʟᴍᴇɴᴜ 』", callback_data: "fun_menu" },
        ],
        [
            { text: "『 ᴄʜᴀᴛ ᴏᴡɴᴇʀ 』", url: "https://wa.me/qr/TYVT4GF6HNTZK1" },
            { text: "『 ꜱᴇᴡᴀ ʙᴏᴛ ᴀᴡ 』", url: "https://rizky598.github.io/id/id" },
        ],
    ];

    setTimeout(async () => {
        await ctx.replyWithPhoto("https://i.ibb.co/prNSmQbj/575d6cd5d449.jpg", {
            caption: mainMenuMessage,
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: mainKeyboard },
        });
    }, 1000);
});

bot.command("addowner", async (ctx) => {
    if (!OWNER_ID(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ").slice(1);
    if (!args[0]) {
        return await ctx.reply("Masukkan ID pengguna untuk dijadikan owner!");
    }
    addOwner(args[0]);
    await ctx.reply(`✅ Pengguna ${args[0]} telah ditambahkan sebagai owner.`);
});

bot.command("addadmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ").slice(1);
    if (!args[0]) {
        return await ctx.reply("Masukkan ID pengguna untuk dijadikan admin!");
    }
    addAdmin(args[0]);
    await ctx.reply(`✅ Pengguna ${args[0]} telah ditambahkan sebagai admin.`);
});

bot.command("addprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ").slice(1);
    if (!args[0] || !args[1]) {
        return await ctx.reply("Masukkan ID pengguna dan durasi (hari) untuk status premium!");
    }
    addPremiumUser(args[0], parseInt(args[1]));
    await ctx.reply(`✅ Pengguna ${args[0]} telah ditambahkan sebagai premium untuk ${args[1]} hari.`);
});

bot.command("delowner", async (ctx) => {
    if (!OWNER_ID(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ").slice(1);
    if (!args[0]) {
        return await ctx.reply("Masukkan ID pengguna untuk dihapus dari owner!");
    }
    removeOwner(args[0]);
    await ctx.reply(`✅ Pengguna ${args[0]} telah dihapus dari owner.`);
});

bot.command("deladmin", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ").slice(1);
    if (!args[0]) {
        return await ctx.reply("Masukkan ID pengguna untuk dihapus dari admin!");
    }
    removeAdmin(args[0]);
    await ctx.reply(`✅ Pengguna ${args[0]} telah dihapus dari admin.`);
});

bot.command("delprem", async (ctx) => {
    if (!OWNER_ID(ctx.from.id) && !isOwner(ctx.from.id) && !isAdmin(ctx.from.id)) {
        return await ctx.reply("❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ").slice(1);
    if (!args[0]) {
        return await ctx.reply("Masukkan ID pengguna untuk dihapus dari premium!");
    }
    removePremiumUser(args[0]);
    await ctx.reply(`✅ Pengguna ${args[0]} telah dihapus dari premium.`);
});

// --- Fun Commands (Semua membutuhkan status premium) ---
bot.command("menuanime", checkPremium, async (ctx) => {
    await sendAnimeMenu(ctx);
});

bot.command("animeneko", checkPremium, async (ctx) => {
    const url = await getSFWImage("neko");
    if (url) {
        await ctx.replyWithPhoto({ url }, { caption: "Ini dia neko imutmu!" });
    } else {
        await ctx.reply("Maaf, tidak dapat mengambil gambar neko saat ini.");
    }
});

bot.command("animewaifu", checkPremium, async (ctx) => {
    const url = await getSFWImage("waifu");
    if (url) {
        await ctx.replyWithPhoto({ url }, { caption: "Waifu idamanmu telah tiba!" });
    } else {
        await ctx.reply("Maaf, tidak dapat mengambil gambar waifu saat ini.");
    }
});

const nsfwCommands = [
    "animehentai",
    "animemilf",
"animeass",
    "animeboobs",
    "animeero",
    "animepussy",
    "animefeet",
    "animeyuri",
    "animetrap",
    "animeblowjob",
    "animecum",
    "animehandjob",
    "animeahegao",
    "animeoral",
    "animegangbang",
    "animeglasses",
    "animethighs",
    "animeuniform",
    "animebondage",
    "animecuckold",
    "animefemdom",
    "animeloli",
    "animeshoto",
    "animesquirting",
    "animeteacher",
    "animetentacles",
    "animeyaoi",
];

nsfwCommands.forEach((cmd) => {
    bot.command(cmd, checkPremium, async (ctx) => {
        const nsfwCategory = cmd.replace("anime", "");
        const url = await getNSFWImage(nsfwCategory);
        if (url) {
            await ctx.replyWithPhoto({ url }, { caption: `🔞 ${nsfwCategory.charAt(0).toUpperCase() + nsfwCategory.slice(1)} anime image` });
        } else {
            await ctx.reply(`❌ Maaf, tidak dapat mengambil gambar ${nsfwCategory} saat ini. Coba lagi nanti atau hubungi admin jika masalah berlanjut.`);
        }
    });
});

bot.command("tiktok", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    await handleTikTokCommand(ctx, args[0]);
});

bot.command("smeme", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    const quotedMessage = ctx.message.reply_to_message;
    await handleSmemeCommand(ctx, args.join(" "), quotedMessage);
});

bot.command("brat", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    await handleBratCommand(ctx, args.join(" "));
});

bot.command("bratvid", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    await handleBratVidCommand(ctx, args.join(" "));
});

bot.command("cekmati", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    await handleCekMatiCommand(ctx, args[0]);
});

bot.command("npm", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    await handleNpmSearchCommand(ctx, args.join(" "));
});

bot.command("ss", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    await handleScreenshotCommand(ctx, args[0]);
});

bot.command("cuaca", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    await handleCuacaCommand(ctx, args.join(" "));
});

bot.command("kopi", checkPremium, async (ctx) => {
    await handleKopiCommand(ctx);
});

bot.command("ai", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    await handleAICommand(ctx, args.join(" "));
});

bot.command("resetai", checkPremium, async (ctx) => {
    await handleResetAICommand(ctx);
});

bot.command(["sticker", "s"], checkPremium, async (ctx) => {
    const quotedMessage = ctx.message.reply_to_message;
    await handleStickerCommand(ctx, quotedMessage);
});

bot.command("vsticker", checkPremium, async (ctx) => {
    const quotedMessage = ctx.message.reply_to_message;
    await handleVideoStickerCommand(ctx, quotedMessage);
});

bot.command("menu", async (ctx) => {
    const waktuRunPanel = getUptime();
    const menuText = `
╭━𓊈 𝐌𝐄𝐍𝐔 ${config.botName} 𓊉━═╣
║☐ ⧽ 📌 𝚄𝙼𝚄𝙼
╿☐ ⧽ /menu - Lihat menu
╽☐ ⧽ /cuaca <kota> - Cek cuaca
╿☐ ⧽ /kopi - Kopi virtual ☕
╽☐ ⧽ /cekmati <url> - Cek website
╿☐ ⧽ /npm <nama> - Cari paket NPM
╽☐ ⧽ /ss <url> - Screenshot web
║☐ ⧽ 📌 𝙼𝙴𝙳𝙸𝙰 & 𝙷𝙸𝙱𝚄𝚁𝙰𝙽
╿☐ ⧽ /tiktok <url> - Download TikTok
╽☐ ⧽ /smeme <teks> - Buat meme
╿☐ ⧽ /sticker - Stiker dari gambar
╽☐ ⧽ /vsticker - Stiker dari video
╿☐ ⧽ /brat <teks> - Gambar Brat
╽☐ ⧽ /bratvid <teks> - Video Brat
╿☐ ⧽ /remini - Tingkatkan kualitas gambar
╽☐ ⧽ /remini <mode> - Mode khusus
║☐ ⧽ 📌 𝙰𝙸
╿☐ ⧽ /ai <pertanyaan> - Chat AI
╽☐ ⧽ /resetai - Reset AI
║☐ ⧽ 📌 𝙰𝙽𝙸𝙼𝙴
╿☐ ⧽ /followers rizky.cyber
╿☐ ⧽ /menuanime - Perintah anime
╿☐ ⧽ /imagelink
╿☐ ⧽ /gempa
╿☐ ⧽ /halodoc asam lambung
╿☐ ⧽ /uploadtele
╿☐ ⧽ /blurbg
╿☐ ⧽ /sensoranime
╿☐ ⧽ /draftjudi
╿☐ ⧽ /bk batu
╿☐ ⧽ /cerita
╿☐ ⧽ /sabda
╰━━━━━𓊈 𝐑𝐈𝐙𝐊𝐘 𝐀𝐏𝐏 𝐒𝐓𝐎𝐑𝐄 𓊉━━━━━━═╣`;
    await ctx.replyWithVideo({ url: config.videoUrl }, { caption: menuText });
    await ctx.replyWithAudio({ url: config.voiceUrl });
});

// --- Callback Handlers ---
bot.action("owner_menu", async (ctx) => {
    await ctx.deleteMessage();
    const waktuRunPanel = getUptime();
    const mainMenuMessage = `\`\`\`
╭━𓊈 𝐑𝐈𝐙𝐊𝐘 𝐀𝐏𝐏 𝐒𝐓𝐎𝐑𝐄 𓊉━═╣
║𝙱𝙾𝚃 𝙽𝙰𝙼𝙴 : ${config.botName}
┃𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0
║𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━━━━━━━━═╣
┏━━『 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨 』
╿☐ ⧽ /addadmin × id
╽☐ ⧽ /deladmin × id
╿☐ ⧽ /addowner × id
╽☐ ⧽ /delowner × id
╿☐ ⧽ /addprem × id
╽☐ ⧽ /delprem × id
┕━━━━━━━━━━━━━━━━━━━━━━━━━━
\`\`\``;
    const mainKeyboard = [
        [
            { text: "𝙱𝙰𝙲𝙺", callback_data: "back" },
            { text: "『 ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅ 』", callback_data: "admin_menu" },
        ],
    ];
await ctx.replyWithPhoto("https://i.ibb.co/prNSmQbj/575d6cd5d449.jpg", {
        caption: mainMenuMessage,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: mainKeyboard },
    });
});

bot.action("admin_menu", async (ctx) => {
    await ctx.deleteMessage();
    const waktuRunPanel = getUptime();
    const mainMenuMessage = `\`\`\`
╭━𓊈 𝐑𝐈𝐙𝐊𝐘 𝐀𝐏𝐏 𝐒𝐓𝐎𝐑𝐄 𓊉━═╣
║𝙱𝙾𝚃 𝙽𝙰𝙼𝙴 : ${config.botName}
┃𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0
║𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━━━━━━━━═╣
┏━━『 𝗔𝗗𝗠𝗜𝗡 𝗠𝗘𝗡𝗨 』
╿☐ ⧽ /addprem × id
╽☐ ⧽ /delprem × id
┕━━━━━━━━━━━━━━━━━━━━━━━━━━
\`\`\``;
    const mainKeyboard = [
        [
            { text: "[ ᴍᴇɴᴜ ]", callback_data: "back" },
            { text: "[ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ]", callback_data: "owner_menu" },
        ],
    ];

    await ctx.replyWithPhoto("https://i.ibb.co/prNSmQbj/575d6cd5d449.jpg", {
        caption: mainMenuMessage,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: mainKeyboard },
    });
});

bot.action("fun_menu", async (ctx) => {
    await ctx.deleteMessage();
    const waktuRunPanel = getUptime();
    const mainMenuMessage = `\`\`\`
╭━𓊈 𝐑𝐈𝐙𝐊𝐘 𝐀𝐏𝐏 𝐒𝐓𝐎𝐑𝐄 𓊉━═╣
║𝙱𝙾𝚃 𝙽𝙰𝙼𝙴 : ${config.botName}
┃𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0
║𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━━━━━━━━═╣
┏━━『 𝗙𝗨𝗡 𝗠𝗘𝗡𝗨 』
╿☐ ⧽ /menuanime - Perintah anime
╽☐ ⧽ /tiktok <url> - Download TikTok
╿☐ ⧽ /smeme <teks> - Buat meme
╽☐ ⧽ /sticker - Stiker dari gambar
╿☐ ⧽ /vsticker - Stiker dari video
╽☐ ⧽ /brat <teks> - Gambar Brat
╿☐ ⧽ /bratvid <teks> - Video Brat
╽☐ ⧽ /cekmati <url> - Cek website
╿☐ ⧽ /npm <nama> - Cari paket NPM
╽☐ ⧽ /ss <url> - Screenshot web
╿☐ ⧽ /cuaca <kota> - Cek cuaca
╽☐ ⧽ /kopi - Kopi virtual
╽☐ ⧽ /followers rizky.cyber
╿☐ ⧽ /ai <pertanyaan> - Chat AI
╽☐ ⧽ /resetai - Reset chat AI
╿☐ ⧽ /imagelink
╿☐ ⧽ /gempa
╿☐ ⧽ /halodoc asam lambung
╿☐ ⧽ /uploadtele
╿☐ ⧽ /blurbg
╿☐ ⧽ /sensoranime
╿☐ ⧽ /draftjudi
╿☐ ⧽ /bk batu
╿☐ ⧽ /cerita 
╿☐ ⧽ /sabda
┕━━━━━━━━━━━━━━━━━━━━━━━━━━
\`\`\``;
    const mainKeyboard = [{ text: "𝙱𝙰𝙲𝙺", callback_data: "back" }];

    await ctx.replyWithPhoto("https://i.ibb.co/prNSmQbj/575d6cd5d449.jpg", {
        caption: mainMenuMessage,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: [mainKeyboard] },
    });
});

bot.action("back", async (ctx) => {
    await ctx.deleteMessage();
    const waktuRunPanel = getUptime();
    const mainMenuMessage = `\`\`\`
╭━𓊈 𝐑𝐈𝐙𝐊𝐘 𝐀𝐏𝐏 𝐒𝐓𝐎𝐑𝐄 𓊉━═╣
║𝙱𝙾𝚃 𝙽𝙰𝙼𝙴 : ${config.botName}
┃𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 3.0
║𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━━━━━━━━═╣
╭━━━━━━━━━━━━━━━━━━━━━
┃ᴋᴀʟᴀᴜ ɪɴɢɪɴ ᴍᴇᴍʙᴇʟɪ ʙᴏᴛ
┃ᴡʜᴀᴛꜱᴀᴘᴘ ᴅᴀɴ ᴘᴀɴᴇʟ ᴄʜᴀᴛ
┃ᴀᴊᴀ ᴀᴅᴍɪɴ ɴᴏᴍᴏʀ ᴅɪ ʙᴀᴡᴀʜ 
┃
╰━━━━━━━━━━━━━━━━━━━━━
\`\`\``;

    const mainKeyboard = [
        [
            { text: "『 ᴏᴡɴᴇʀ ᴍᴇɴᴜ 』", callback_data: "owner_menu" },
            { text: "『 ᴀʟʟᴍᴇɴᴜ 』", callback_data: "fun_menu" },
        ],
        [
            { text: "『 ᴄʜᴀᴛ ᴏᴡɴᴇʀ 』", url: "https://wa.me/qr/TYVT4GF6HNTZK1" },
            { text: "『 ꜱᴇᴡᴀ ʙᴏᴛ ᴀᴡ 』", url: "https://rizky598.github.io/id/id" },
        ],
    ];

    await ctx.replyWithPhoto("https://i.ibb.co/prNSmQbj/575d6cd5d449.jpg", {
        caption: mainMenuMessage,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: mainKeyboard },
    });
});


// --- Fungsi Remini (Dipindahkan dari remini.js) ---
async function remini(imageBuffer, mode) {
    return new Promise((resolve, reject) => {
        try {
            const supportedModes = ["enhance", "recolor", "dehaze"];
            if (!supportedModes.includes(mode)) mode = "enhance";

            const url = `https://inferenceengine.vyro.ai/${mode}`;
            const formData = new FormData();
            formData.append("model_version", 1);
            formData.append("image", imageBuffer, {
                filename: "enhance_image_body.jpg",
                contentType: "image/jpeg",
            });

            const options = {
                method: "POST",
                headers: {
                    ...formData.getHeaders(),
                    "User-Agent": "okhttp/4.9.3",
                    Connection: "Keep-Alive",
                },
            };

            const req = https.request(url, options, (res) => {
                if (res.statusCode !== 200) {
                    return reject(new Error(`HTTP Error: ${res.statusCode}`));
                }

                const chunks = [];
                res.on("data", (chunk) => chunks.push(chunk));
                res.on("end", () => resolve(Buffer.concat(chunks)));
            });

            req.on("error", (err) => reject(err));
            formData.pipe(req);
        } catch (err) {
            reject(err);
        }
    });
}

// Fungsi untuk memproses gambar melalui DeepAI
// async function r/*
async function remini(imageBuffer, mode = "enhance") {
    const form = new FormData();
    form.append("image", imageBuffer, { filename: "photo.jpg" });

    const response = await fetch("https://api.deepai.org/api/torch-srgan", {
        method: "POST",
        headers: {
            "Api-Key": config.DEEPAI_API_KEY,
            ...form.getHeaders()
        },
        body: form
    });

    const result = await response.json();
    if (!result.output_url) {
        throw new Error("Gagal mendapatkan gambar dari DeepAI");
    }

    const enhancedImage = await fetch(result.output_url).then(res => res.buffer());
    return enhancedImage;
}
// Fungsi utama yang menangani perintah /remini atau /hd
async function handleReminiCommand(ctx, quotedMessage, mode) {
    if (!quotedMessage || !quotedMessage.photo) {
        return await ctx.reply("🖼️ Balas gambar dengan perintah /remini atau /remini <mode> untuk meningkatkan kualitasnya!");
    }

    try {
        await ctx.replyWithChatAction("upload_photo");

        const photo = quotedMessage.photo[quotedMessage.photo.length - 1];
        const imageBuffer = await ctx.telegram.getFileLink(photo.file_id)
            .then((url) => fetch(url).then((res) => res.buffer()));

        await ctx.reply(`❌ Fitur remini sedang dalam perbaikan. Silakan coba lagi nanti.`);
    } catch (error) {
        console.error("❌ Remini error:", error);
        await ctx.reply(`❌ Fitur remini sedang dalam perbaikan. Silakan coba lagi nanti.`);
    }
}

// Pendaftaran command /remini dan /hd




async function handleImageSearch(ctx, query) {
    if (!query) {
        return await ctx.reply("🔎 Masukkan kata kunci pencarian!\nContoh: /pin sunset");
    }

    try {
        await ctx.replyWithChatAction("typing");
        await sleep(500);
        await ctx.replyWithChatAction("upload_photo");

        const res = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=1`, {
            headers: {
                Authorization: config.PEXELS_API_KEY
            }
        });

        const data = await res.json();
        const images = data.photos || [];

        if (images.length === 0) {
            return await ctx.reply(`❌ Tidak ditemukan gambar untuk: *${query}*`, { parse_mode: "Markdown" });
        }

        const imageUrl = images[0].src.original;

        await ctx.replyWithPhoto(
            { url: imageUrl },
            { caption: `🔍 Hasil pencarian untuk: *${query}*`, parse_mode: "Markdown" }
        );
    } catch (err) {
        console.error("❌ Error dalam /pin:", err);
        await ctx.reply("❌ Terjadi kesalahan saat mencari gambar. Coba lagi nanti.");
    }
}

bot.command("pin", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    const query = args.join(" ").trim();

    await handleImageSearch(ctx, query);
});

async function handleFollowersCommand(ctx, platform, username) {
    if (!platform || !username) {
        return await ctx.reply("❌ Format salah!\nContoh: /followers twitter elonmusk");
    }

    try {
        if (platform.toLowerCase() === "twitter") {
            const res = await fetch(`https://api.popcat.xyz/xuser?user=${username}`);
            const data = await res.json();

            if (data.error) {
                return ctx.reply("❌ Username tidak ditemukan!");
            }

            const msg = `📊 *Profil Twitter: @${data.username}*\n👤 Nama: ${data.name}\n👥 Followers: *${data.followers.toLocaleString()}*\n📍 Lokasi: ${data.location || "-"}\n🔗 https://twitter.com/${data.username}`;
            return ctx.reply(msg, { parse_mode: "Markdown" });
        } else {
            return ctx.reply("❌ Saat ini hanya mendukung: `twitter`", { parse_mode: "Markdown" });
        }
    } catch (e) {
        console.error("Follower error:", e);
        return ctx.reply("⚠️ Gagal mengambil data followers.");
    }
}

bot.command("followers", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    const platform = args[0];
    const username = args[1];

    await handleFollowersCommand(ctx, platform, username);
});


async function handleImageToLinkCommand(ctx, quotedMessage) {
    if (!quotedMessage || !quotedMessage.photo) {
        return await ctx.reply("🖼️ Balas gambar dengan perintah /imagelink untuk mengubahnya jadi URL!");
    }

    try {
        const photo = quotedMessage.photo[quotedMessage.photo.length - 1];
        const imageBuffer = await ctx.telegram.getFileLink(photo.file_id)
            .then((url) => fetch(url).then((res) => res.buffer()));

        const base64Image = imageBuffer.toString("base64");

        const form = new FormData();
        form.append("image", base64Image);

        const response = await fetch(`https://api.imgbb.com/1/upload?key=${config.IMGBB_API_KEY}`, {
            method: "POST",
            body: form
        });

        const result = await response.json();

        if (!result.success) {
            throw new Error("Gagal upload ke ImgBB");
        }

        const imageUrl = result.data.url;

        await ctx.reply(`✅ Gambar berhasil diunggah:\n${imageUrl}`);
    } catch (error) {
        console.error("❌ Image upload error:", error);
        await ctx.reply(`❌ Gagal mengunggah gambar: ${error.message}`);
    }
}

bot.command("imagelink", checkPremium, async (ctx) => {
    const quotedMessage = ctx.message.reply_to_message;
    await ctx.replyWithChatAction("upload_photo");
    await handleImageToLinkCommand(ctx, quotedMessage);
});

async function gempa() {
    try {
        const { data } = await axios.get('https://www.bmkg.go.id/gempabumi/gempabumi-dirasakan.bmkg');
        const $ = cheerio.load(data);

        const drasa = [];
        $('table > tbody > tr:nth-child(1) > td:nth-child(6) > span').each((i, el) => {
            const dir = $(el).text().trim();
            drasa.push(dir);
        });

        const format = {
            image: "https://www.bmkg.go.id" + $('div.modal-body > div > div:nth-child(1) > img').attr('src'),
            magnitude: $('table > tbody > tr:nth-child(1) > td:nth-child(4)').text().trim(),
            kedalaman: $('table > tbody > tr:nth-child(1) > td:nth-child(5)').text().trim(),
            wilayah: $('table > tbody > tr:nth-child(1) > td:nth-child(6) > a').text().trim(),
            waktu: $('table > tbody > tr:nth-child(1) > td:nth-child(2)').text().trim(),
            lintang_bujur: $('table > tbody > tr:nth-child(1) > td:nth-child(3)').text().trim(),
            dirasakan: drasa.join(", ")
        };

        return {
            source: "www.bmkg.go.id",
            data: format
        };
    } catch (err) {
        throw new Error("Gagal mengambil data gempa dari BMKG");
    }
}

bot.command("gempa", checkPremium, async (ctx) => {
    try {
        const result = await gempa();
        const { data } = result;

        const caption = `🌋 *Info Gempa Terkini*\n` +
                        `📍 Wilayah: *${data.wilayah}*\n` +
                        `📅 Waktu: ${data.waktu}\n` +
                        `🌐 Koordinat: ${data.lintang_bujur}\n` +
                        `💥 Magnitudo: *${data.magnitude}*\n` +
                        `📏 Kedalaman: ${data.kedalaman}\n` +
                        `🤕 Dirasakan: ${data.dirasakan || "-"}\n\n` +
                        `Sumber: www.bmkg.go.id`;

        await ctx.replyWithPhoto({ url: data.image }, { caption, parse_mode: "Markdown" });
    } catch (err) {
        console.error("❌ Error gempa:", err);
        await ctx.reply("❌ Gagal mengambil data gempa.");
    }
});


async function halodoc(penyakit = "") {
    const artikelURL = `https://www.halodoc.com/artikel/search/${penyakit}`;
    const obatURL = `https://www.halodoc.com/obat-dan-vitamin/search/${penyakit}`;

    const getArtikelSearch = async () => {
        const { data } = await axios.get(artikelURL);
        const $ = cheerio.load(data);
        const articles = [];

        $("magneto-card").each((i, el) => {
            const title = $(el).find("header a").text().trim();
            const description = $(el).find(".description").text().trim();
            const link = $(el).find("header a").attr("href");
            const image = $(el).find("picture img").attr("src");

            if (title && link) {
                articles.push({
                    title,
                    description,
                    link: `https://www.halodoc.com${link}`,
                    image,
                });
            }
        });

        return articles;
    };

    const getObatSearch = async () => {
        const { data } = await axios.get(obatURL);
        const $ = cheerio.load(data);
        const list = [];

        $("li.custom-container__list__container").each((i, el) => {
            const title = $(el).find(".hd-base-product-search-card__title").text().trim();
            const subtitle = $(el).find(".hd-base-product-search-card__subtitle").text().trim();
            const price = $(el).find(".hd-base-product-search-card__price").text().trim();
            const image = $(el).find(".hd-base-image-mapper__img").attr("src");
            const link = $(el).find(".hd-base-product-search-card__content a").attr("href");

            if (title && link) {
                list.push({
                    title,
                    subtitle,
                    price,
                    image,
                    link: `https://www.halodoc.com${link}`
                });
            }
        });

        return list;
    };

    return {
        getArtikelSearch,
        getObatSearch
    };
}

bot.command("halodoc", checkPremium, async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    const keyword = args.join(" ");

    if (!keyword) {
        return ctx.reply("❗ Masukkan kata kunci penyakit.\nContoh: /halodoc diabetes");
    }

    try {
        const { getArtikelSearch, getObatSearch } = halodoc(keyword);

        const [artikelList, obatList] = await Promise.all([
            getArtikelSearch(),
            getObatSearch()
        ]);

        let teks = `🩺 *Hasil Pencarian Halodoc untuk:* _${keyword}_\n\n`;

        if (artikelList.length > 0) {
            teks += "📚 *Artikel Terkait:*\n";
            artikelList.slice(0, 3).forEach((a, i) => {
                teks += `\n${i + 1}. [${a.title}](${a.link})\n${a.description}\n`;
            });
        } else {
            teks += "📚 Tidak ada artikel ditemukan.\n";
        }

        if (obatList.length > 0) {
            teks += `\n💊 *Obat yang Terkait:*\n`;
            obatList.slice(0, 3).forEach((o, i) => {
                teks += `\n${i + 1}. [${o.title}](${o.link})\n${o.subtitle} - ${o.price}`;
            });
        } else {
            teks += "\n💊 Tidak ada obat ditemukan.";
        }

        await ctx.reply(teks, { parse_mode: "Markdown" });
    } catch (err) {
        console.error("❌ Halodoc error:", err);
        await ctx.reply("❌ Gagal mengambil data dari Halodoc.");
    }
});


async function uptotelegra(Path) {
    return new Promise(async (resolve, reject) => {
        if (!fs.existsSync(Path)) return reject(new Error("File tidak ditemukan!"));
        try {
            const form = new FormData();
            form.append("file", fs.createReadStream(Path));

            const { data } = await axios({
                url: "https://telegra.ph/upload",
                method: "POST",
                headers: {
                    ...form.getHeaders()
                },
                data: form
            });

            resolve("https://telegra.ph" + data[0].src);
        } catch (err) {
            reject(new Error("Upload gagal: " + err.message));
        }
    });
}

bot.command("uploadtele", checkPremium, async (ctx) => {
    const quoted = ctx.message.reply_to_message;

    if (!quoted || !quoted.document && !quoted.photo) {
        return ctx.reply("❗ Balas gambar atau file dengan perintah /uploadtele");
    }

    try {
        await ctx.replyWithChatAction("upload_photo");

        const file = quoted.document || quoted.photo?.slice(-1)[0];
        const link = await ctx.telegram.getFileLink(file.file_id);
        const res = await fetch(link.href);
        const buffer = await res.buffer();

        const tempFile = `./temp_${Date.now()}.jpg`;
        fs.writeFileSync(tempFile, buffer);

        const uploadedLink = await uptotelegra(tempFile);
        fs.unlinkSync(tempFile);

        await ctx.reply(`✅ File berhasil diupload ke:\n${uploadedLink}`);
    } catch (err) {
        console.error("❌ UploadTele error:", err);
        await ctx.reply("❌ Gagal upload ke telegra.ph");
    }
});



async function handleBlurBgCommand(ctx, quotedMessage) {
    if (!quotedMessage || !quotedMessage.photo) {
        return ctx.reply("📷 Balas gambar dengan perintah /blurbg untuk menghapus atau ngeblur background-nya.");
    }

    try {
        const photo = quotedMessage.photo[quotedMessage.photo.length - 1];
        const fileLink = await ctx.telegram.getFileLink(photo.file_id);
        const res = await fetch(fileLink.href);
        const buffer = await res.buffer();

        const form = new FormData();
        form.append("image_file", buffer, {
            filename: "image.jpg"
        });
        form.append("size", "auto");
        form.append("bg_blur", "20"); // nilai blur antara 1–100

        const response = await axios.post("https://api.remove.bg/v1.0/removebg", form, {
            headers: {
                "X-Api-Key": config.REMOVEBG_API_KEY,
                ...form.getHeaders()
            },
            responseType: "arraybuffer"
        });

        const output = Buffer.from(response.data);

        await ctx.replyWithPhoto(
            { source: output },
            { caption: "✅ Background berhasil diblur!", parse_mode: "Markdown" }
        );
    } catch (err) {
        console.error("❌ blurbg error:", err);
        ctx.reply("❌ Gagal memproses gambar. Pastikan API Key valid atau coba lagi.");
    }
}

bot.command("blurbg", checkPremium, async (ctx) => {
    const quotedMessage = ctx.message.reply_to_message;
    await ctx.replyWithChatAction("upload_photo");
    await handleBlurBgCommand(ctx, quotedMessage);
});


async function handleSensorAnimeCommand(ctx, quotedMessage) {
    if (!quotedMessage || !quotedMessage.photo) {
        return ctx.reply("🖼️ Balas gambar anime dengan perintah /sensoranime untuk menyensor warna kulit.");
    }

    try {
        await ctx.replyWithChatAction("upload_photo");

        const photo = quotedMessage.photo[quotedMessage.photo.length - 1];
        const fileLink = await ctx.telegram.getFileLink(photo.file_id);
        const res = await fetch(fileLink.href);
        const buffer = await res.buffer();

        const filePath = `./anime_${Date.now()}.jpg`;
        fs.writeFileSync(filePath, buffer);

        const image = await Jimp.read(filePath);
        const { width, height } = image.bitmap;

        // Sensor warna kulit anime
        image.scan(0, 0, width, height, function (x, y, idx) {
            const r = this.bitmap.data[idx + 0];
            const g = this.bitmap.data[idx + 1];
            const b = this.bitmap.data[idx + 2];

            // Deteksi warna kulit anime (kisarannya bisa kamu eksperimen)
            if (r > 180 && g > 140 && b > 120 && r > g && g > b) {
                // Ganti jadi hitam
                this.bitmap.data[idx + 0] = 0;
                this.bitmap.data[idx + 1] = 0;
                this.bitmap.data[idx + 2] = 0;
            }
        });

        const outputPath = `./output_${Date.now()}.jpg`;
        await image.writeAsync(outputPath);

        await ctx.replyWithPhoto({ source: outputPath }, { caption: "🕶️ Kulit berhasil disensor (deteksi warna kulit)." });

        fs.unlinkSync(filePath);
        fs.unlinkSync(outputPath);
    } catch (err) {
        console.error("❌ sensoranime error:", err);
        await ctx.reply("❌ Gagal memproses gambar.");
    }
}

bot.command("sensoranime", checkPremium, async (ctx) => {
    const quotedMessage = ctx.message.reply_to_message;
    await handleSensorAnimeCommand(ctx, quotedMessage);
});

function getRandomCharacter() {
    const characters = [
        "🦸 Superhero",
        "🐉 Naga",
        "🤖 Robot",
        "🧙 Penyihir",
        "⚽ Pemain Bola",
        "🧛 Vampir",
        "🐺 Werewolf",
        "🏴‍☠️ Bajak Laut",
        "🦁 Singa",
        "👽 Alien"
    ];
    const name = characters[Math.floor(Math.random() * characters.length)];
    const power = Math.floor(Math.random() * 100) + 1;
    return { name, power };
}

function createDraftResult(username) {
    const draft = [getRandomCharacter(), getRandomCharacter(), getRandomCharacter()];
    const total = draft.reduce((acc, c) => acc + c.power, 0);

    let teks = `🎮 *Draft Judi untuk @${username}*\n\n`;
    draft.forEach((char, i) => {
        teks += `#${i + 1} ${char.name} → *${char.power}*\n`;
    });
    teks += `\n🏆 *Total Power:* ${total}`;

    return teks;
}

bot.command("draftjudi", async (ctx) => {
    const username = ctx.from.username || ctx.from.first_name;
    const hasil = createDraftResult(username);
    await ctx.reply(hasil, { parse_mode: "Markdown" });
});

async function handleSuitGame(ctx, playerChoice) {
    const pilihanValid = ["batu", "gunting", "kertas"];
    playerChoice = playerChoice.toLowerCase();

    if (!pilihanValid.includes(playerChoice)) {
        return ctx.reply("❗ Pilihan tidak valid!\nGunakan: /bk batu | gunting | kertas");
    }

    const botChoice = pilihanValid[Math.floor(Math.random() * 3)];

    let hasil;
    if (playerChoice === botChoice) {
        hasil = "🤝 Seri!";
    } else if (
        (playerChoice === "batu" && botChoice === "gunting") ||
        (playerChoice === "gunting" && botChoice === "kertas") ||
        (playerChoice === "kertas" && botChoice === "batu")
    ) {
        hasil = "🎉 Kamu Menang!";
    } else {
        hasil = "😈 Bot Menang!";
    }

    const teks = `🧠 *Suit vs Bot*\n\n👤 Kamu: *${playerChoice}*\n🤖 Bot: *${botChoice}*\n\n🏆 ${hasil}`;
    await ctx.reply(teks, { parse_mode: "Markdown" });
}

bot.command("bk", async (ctx) => {
    const args = ctx.message.text.split(" ").slice(1);
    const pilihan = args[0];

    if (!pilihan) {
        return ctx.reply("Ketik: /bk batu | gunting | kertas");
    }

    await handleSuitGame(ctx, pilihan);
});

function getRandomCerita() {
    const ceritaList = [
        `👻 *Cerita Horor 1: Penunggu Toilet Sekolah*\n
Malam itu, Dani lembur di sekolah untuk latihan teater. Saat ke toilet, dia melihat semua pintu terkunci—kecuali satu. Saat masuk, dia dengar suara berbisik, “Pinjem tissuuu…” tapi dia sendirian. Ketika Dani keluar, ada jejak kaki basah dari toilet ke ruang teater… padahal lantainya kering.`,
        
        `🌑 *Cerita Horor 2: Boneka di Lemari*\n
Santi menemukan boneka lucu di pasar malam. Ia simpan di lemari. Setiap malam, posisi boneka itu berubah. Kadang di meja, kadang di tempat tidur. Suatu malam, boneka itu duduk di dada Santi, menatapnya sambil tersenyum, dan berbisik, “Sekarang kamu yang gantian di lemari.”`,

        `🧟 *Cerita Horor 3: Jalan Pulang Tak Pernah Sampai*\n
Rino pulang larut lewat jalan pintas desa. Tapi jalan itu terus berulang, seperti tidak berujung. Setiap kali belok, rumah yang sama muncul. Hingga akhirnya dia melihat dirinya sendiri di depan motor, menatap balik... dan tertawa.`,

        `🌕 *Cerita Horor 4: Hantu Panggil Nama*\n
Ika sering dengar seseorang memanggil namanya di kamar kos, “Ikaa…” Tapi ketika dilihat, tidak ada siapa-siapa. Hingga malam itu, dia lihat bayangan berdiri di sudut ruangan, mengucapkan, “Aku sudah lama di sini, cuma kamu yang baru sadar.”`,

        `😱 *Cerita Horor 5: Foto Bersama di Kuburan*\n
Geng anak muda selfie di kuburan buat konten. Tapi satu wajah di foto tidak ada saat mereka ambil gambar. Wajah itu muncul di tengah-tengah, menatap kamera dengan mata hitam legam, dan semua handphone mati bersamaan.`,

        `🕯️ *Cerita Mistis 6: Lilin Menyala Sendiri*\n
Aldi sedang mati lampu dan nyalakan lilin. Saat lilin padam, ia ke dapur. Tapi saat balik, lilin menyala lagi… dan ada tambahan lilin lain menyala di sebelah. Aldi tinggal sendiri.`,

        `🎭 *Cerita Ringan: Kesurupan di Panggung*\n
Dalam pementasan teater, Indah memainkan tokoh kerasukan. Penonton kagum aktingnya. Tapi saat selesai, Indah masih bicara dengan suara berat… ternyata dia belum keluar dari karakternya. Atau… bukan dia lagi.`,

        `🤡 *Cerita Lucu Gelap: Badut Jam 3 Pagi*\n
Dinda pesan ojek online, tapi yang datang badut naik sepeda mini. Dia pikir itu prank—sampai badut itu kasih boneka lalu hilang tanpa jejak. Saat dicek di aplikasi, ternyata tidak ada histori perjalanan sama sekali…`,

        `📚 *Cerita Nyata (Konon)*\n
Dalam satu foto angkatan SMA, terlihat jelas satu siswa yang tidak dikenali oleh siapa pun. Setelah ditelusuri, itu adalah wajah dari siswa yang meninggal di tahun sebelumnya... di ruangan yang sama saat foto itu diambil.`
    ];

    const random = ceritaList[Math.floor(Math.random() * ceritaList.length)];
    return random;
}

bot.command("cerita", async (ctx) => {
    const cerita = getRandomCerita();
    await ctx.reply(cerita, { parse_mode: "Markdown" });
});

function getRandomSabda() {
    const sabdaList = [
        "🕊️ *“Jangan risaukan rezeki, karena yang menutup pintu adalah manusia, tapi yang memberi rezeki adalah Allah.”*",
        "🌾 *“Orang yang paling kuat adalah orang yang mampu menahan amarahnya ketika dia mampu membalas.”*",
        "🕌 *“Sholat bukan tentang memohon apa yang kamu inginkan, tapi tentang bersyukur atas apa yang sudah kamu miliki.”*",
        "📿 *“Dunia ini hanyalah tempat singgah, jangan terlalu mencintainya karena kita tak akan lama di sini.”*",
        "🤲 *“Kadang, Allah tidak mengubah keadaanmu. Tapi mengubah hatimu agar kuat menghadapi keadaan itu.”*",
        "🕋 *“Istiqomah memang berat, karena surga bukan untuk mereka yang malas.”*",
        "⏳ *“Jangan menunggu kaya baru bersedekah, karena bersedekah bisa jadi sebab datangnya kekayaan.”*",
        "📖 *“Bacalah Al-Qur’an, karena ia akan menjadi syafa’at bagimu di hari kiamat.”* — HR. Muslim",
        "🌙 *“Berdoalah bukan karena kamu lemah, tapi karena kamu tahu hanya Allah tempat bergantung yang sejati.”*",
        "😌 *“Ketika dunia menolakmu, ingatlah bahwa surga tidak pernah tutup pintu.”*",
        "💔 *“Tak ada luka yang abadi, kecuali kamu terus mengukirnya di hati.”*",
        "🎯 *“Jika kamu tidak menemukan jalan, buatlah jalan. Tapi jangan pernah tinggalkan Allah dalam perjalanan itu.”*",
        "🧕 *“Wanita yang menutup auratnya bukan karena sempurna, tapi karena ingin taat.”*",
        "🌱 *“Terkadang, Allah membuatmu hancur agar kamu bisa dibangun kembali, lebih kuat.”*",
        "🛐 *“Sholat bukan untuk Allah. Sholat untuk kamu. Allah tak butuh sholatmu, tapi kamu butuh hidayah-Nya.”*",
        "🧠 *“Memaafkan itu bukan berarti lemah. Itu artinya kamu cukup kuat untuk melepaskan luka.”*",
        "🌤️ *“Setiap hari adalah kesempatan baru untuk mendekat kepada-Nya. Jangan tunggu dosa menumpuk.”*",
        "👣 *“Jalan menuju surga itu sempit dan menanjak. Tapi ujungnya indah tak terlukiskan.”*",
        "🕊️ *“Tenang, yang ditulis untukmu tidak akan menjadi milik orang lain.”*",
        "🔁 *“Jangan benci prosesmu. Karena di situlah Allah sedang memperbaiki jalan hidupmu.”*",
        "🔥 *“Setan tidak peduli seberapa banyak kamu tahu. Dia hanya peduli apakah kamu mengamalkannya.”*",
        "🛎️ *“Jangan sibuk memperbaiki orang lain, sementara hatimu sendiri retak tanpa kamu sadari.”*",
        "🌌 *“Langit tak pernah berhenti memberi hujan. Seperti Allah yang tak pernah berhenti memberi rahmat.”*",
        "💬 *“Sedikit bicara, banyak dzikir. Itulah kunci ketenangan.”*",
        "🌿 *“Kesendirian bukan siksaan. Kadang itu cara Allah mendekatkanmu pada-Nya.”*",
        "🕰️ *“Waktu tidak akan menunggumu. Tapi Allah selalu menunggumu untuk kembali.”*",
        "📿 *“Zikir adalah pengingat, bahwa meski dunia sibuk, hatimu masih terikat pada Yang Esa.”*",
        "💡 *“Kejayaan bukanlah saat kamu dilihat manusia, tapi saat Allah ridha atas langkahmu.”*",
        "🛤️ *“Hijrah itu tidak mudah. Tapi ingat, surga tidak murah.”*",
        "🎁 *“Doa adalah hadiah dari Allah. Bahkan sebelum kamu selesai memintanya, Dia sudah menyiapkannya.”*",
        "🏔️ *“Sebesar apapun masalahmu, Allah jauh lebih besar.”*"
    ];

    return sabdaList[Math.floor(Math.random() * sabdaList.length)];
}

bot.command("sabda", async (ctx) => {
    const sabda = getRandomSabda();
    await ctx.reply(sabda, { parse_mode: "Markdown" });
});
// --- Inisialisasi Bot ---


bot.launch().then(() => {
    console.log(chalk.green.bold('Bot Telegram berjalan! Tekan Ctrl+C untuk menghentikan.'));
}).catch(err => {
    console.error(chalk.red.bold('Gagal meluncurkan bot:'), err);
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));


